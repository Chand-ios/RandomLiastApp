//
//  APICallingViewModel.swift
//  Flypigeon
//
//  Created by FLYPIGEON on 13/09/22.
//

import Foundation
import Foundation
import UIKit
import Alamofire
class APICallingViewModel: UIViewController {
    
    static let shared = APICallingViewModel()
    public static func getRidesList(api:String,parameters:[String:Any],completion: @escaping(RandomModel?)->Void)  {
        
        WebSevicesAPICalling.shared.ApiRequest(api: api, method: "GET", parameters: parameters) { (data, val, error) in
            guard let data11 = data else { return }
            do{
                let res = try JSONDecoder().decode(RandomModel?.self, from: data11)
                completion(res)
                 print("cghvdghcdvhcv",res as Any)
            }catch{
                completion(nil)
                print("Error on parsing")
            }
        }
    }
}
   
