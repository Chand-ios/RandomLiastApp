//
//  WebSevicesAPICalling.swift
//  Flypigeon
//
//  Created by FLYPIGEON on 13/09/22.
//

import Foundation
import AVFoundation
import UIKit
import Alamofire
import AMProgressHUD
class WebSevicesAPICalling {
    
    
    static let shared = WebSevicesAPICalling()
//https://randomuser.me/api/?results=50
    var baseURL1 = "https://randomuser.me/api/?"
    //"http://3.111.62.245/api/"
    //"http://test.flypigeon.com/api/"
//http://business.flypigeon.com/
    func showAlert(title: String, msg: String) {
        let alert = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        if let topController = UIApplication.shared.windows[0].rootViewController {
            topController.present(alert, animated: true, completion: nil)
        }
        let when = DispatchTime.now() + 3
        DispatchQueue.main.asyncAfter(deadline: when){
            alert.dismiss(animated: true, completion: nil)
        }
    }

   
    func ApiRequest(api: String,method:String,parameters:[String:Any],completion: @escaping(Data?,Any?,Error?)->Void)   {
       
        AMProgressHUD.show()

        let color = UIColor.darkGray.withAlphaComponent(0.7)
        let baseUrl1 = baseURL1
        guard let url = URL(string: baseUrl1 + api) else {
            completion(nil, nil, nil)
            return
        }
        print(parameters)
        var header:HTTPHeaders = [:]
        header["contentType"] = "application/json"
        header["Accept"] = "application/json"
        var apiRequest = URLRequest(url: url)
        apiRequest.httpMethod = method
        apiRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if method == "POST"
        {
            apiRequest.httpBody = try! JSONSerialization.data(withJSONObject: parameters)
        }

        AF.request(apiRequest).responseJSON { response in
        
        //request(url, method: method, parameters: parameters,encoding: URLEncoding.default,headers: header).responseJSON(completionHandler: { (response) in
            print(response)
            let code = response.response?.statusCode
            if code == 401{
                self.showAlert(title: "error\(code ?? 0)", msg: "Something went wrong")
            }
            switch(response.result) {
            case .success(_):
                if let data = response.data{
                    completion(data, response.value, response.error)
                }
               // SVProgressHUD.dismiss()
                AMProgressHUD.dismiss()
                break
            case .failure(_):
                completion(nil, nil, response.error)
              //  SVProgressHUD.dismiss()
                let code = response.response?.statusCode
                print("error on service call1", response.error?.localizedDescription as Any)
                self.showAlert(title: "error(\(code ?? 0))", msg: "\(response.error?.localizedDescription as Any)")
                AMProgressHUD.dismiss()
                break
            }
        }
    }
 
}
