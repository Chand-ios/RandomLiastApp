//
//  ViewController.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 02/02/23.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var filterBtn: UIButton!
    @IBOutlet weak var maleBtn: UIButton!
    @IBOutlet weak var femaleBtn: UIButton!
    @IBOutlet weak var genderView: UIView!
    var filterdata: [String] = []

    var ResultArray:[Result] = []
    var nameArr:[String] = []
    var filterdataaaaArr:[Result] = []

    @IBOutlet weak var vehicleTblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRidesList()
        vehicleTblView.delegate = self
        vehicleTblView.dataSource = self
        
    }
    @IBAction func filterAction(_ sender: UIButton) {
        if sender.isSelected
        {
            genderView.isHidden = true
            sender.isSelected = false
        }
        else{
            genderView.isHidden = false
            sender.isSelected = true
        }
       
        
    }
    @IBAction func maleAction(_ sender: UIButton) {
        
        genderView.isHidden = true
        filterdataaaaArr = ResultArray.filter{ ($0.gender == "male") }
        vehicleTblView.reloadData()
    }
    @IBAction func femaleAction(_ sender: UIButton) {
       
        filterdataaaaArr = ResultArray.filter{ ($0.gender == "female") }
        genderView.isHidden = true
        vehicleTblView.reloadData()
    }
    
    //MARK: - ApI Caling
    func getRidesList()
    {
        nameArr.removeAll()
        let parameters : [String:Any] = [:]
 //   https://randomuser.me/api/?results=50

        APICallingViewModel.getRidesList(api:"results=50", parameters: parameters) { [self] (responce) in
            DispatchQueue.main.async { [self] in
                // print("response",responce as Any)
                if responce != nil{
                    //print(responce!)
                    let resultss = responce?.results
                    ResultArray = resultss ?? []
                    filterdataaaaArr = ResultArray
                    vehicleTblView.reloadData()
                    for item in ResultArray
                    {
                        let name = "\(item.name.first ?? "")" +  " \(item.name.last ?? "")"
                        nameArr.append(name)
                    }
                    
                }
            }
        }
    }
    
    
    //MARK: - Tableview Delegate Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterdataaaaArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableViewCell", for: indexPath) as! HomeTableViewCell

        cell.nameLbl.text = "\(filterdataaaaArr[indexPath.row].name.first ?? "")" + " \(ResultArray[indexPath.row].name.last ?? "")"
        
        let imgobject = filterdataaaaArr[indexPath.row].picture.large ?? ""
        let url = URL(string: imgobject)!
        DispatchQueue.main.async {
            if let data = try? Data(contentsOf: url)
            {
                cell.Img.image = UIImage(data: data)
            }
        }
        
        cell.selectionStyle = .none
        cell.bgvieew.layer.cornerRadius = 8
        cell.bgvieew.layer.shadowColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1).cgColor
        cell.bgvieew.layer.shadowOpacity = 0.5
        cell.bgvieew.layer.shadowOffset = .zero
        cell.bgvieew.layer.shadowRadius = 5
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let navVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        
        navVC.nameStr = "\(filterdataaaaArr[indexPath.row].name.first ?? "")" +  " \(filterdataaaaArr[indexPath.row].name.last ?? "")"
        navVC.ageStr = String(filterdataaaaArr[indexPath.row].dob.age ?? 0)
        navVC.countryStr = filterdataaaaArr[indexPath.row].location.country ?? ""
        navVC.addressStr = filterdataaaaArr[indexPath.row].location.timezone.description ?? ""
        navVC.phoneStr = filterdataaaaArr[indexPath.row].phone ?? ""
        navVC.imageStr = filterdataaaaArr[indexPath.row].picture.large ?? ""
        navVC.genderStr = filterdataaaaArr[indexPath.row].gender ?? ""
        
       
        self.navigationController?.pushViewController(navVC, animated: true)

    }
    
}

extension ViewController: UISearchBarDelegate
{
  func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
    //filterdata = []
    if searchText == ""
    {
        filterdataaaaArr = ResultArray
    }
      else{
          filterdataaaaArr = ResultArray.filter{ ($0.name.first?.contains(searchText))! }
          print(filterdataaaaArr.map({"\($0.name.first ?? "i")"}))
      }
     
    self.vehicleTblView.reloadData()
  }
}
