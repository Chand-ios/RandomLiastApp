//
//  VehicleTableViewCell.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 02/02/23.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var Img: UIImageView!
    @IBOutlet weak var bgvieew: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
