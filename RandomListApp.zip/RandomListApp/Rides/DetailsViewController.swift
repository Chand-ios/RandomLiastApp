//
//  DetailsViewController.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 02/02/23.
//

import UIKit

class DetailsViewController: UIViewController {
 
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var Image: UIImageView!

    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var country: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var phone: UILabel!
    
    var nameStr,imageStr,ageStr,addressStr,countryStr,genderStr,phoneStr : String!

    var randomDetailsArr:RandomModel?
    var vinStr, modelStr, colorStr, carTypeStr : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLbl.text = nameStr ?? ""
        gender.text = genderStr ?? ""
        address.text = addressStr ?? ""
        country.text = countryStr ?? ""
        age.text = ageStr ?? ""
        phone.text = phoneStr ?? ""
        nameLbl.text = nameStr ?? ""
        nameLbl.text = nameStr ?? ""
        
        let url = URL(string: imageStr)!
        let data = try? Data(contentsOf: url)
        Image.image = UIImage(data: data!)

    }
    // MARK: - UI Setup
    
    @IBAction func backAction(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }

}
