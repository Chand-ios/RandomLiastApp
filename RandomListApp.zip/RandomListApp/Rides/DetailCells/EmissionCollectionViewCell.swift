//
//  EmissionCollectionViewCell.swift
//  Rides
//
//  Created by TEKKR AGRI ORGANICS PRIVATE LIMITED on 03/02/23.
//

import UIKit

class EmissionCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var kilometerLbl: UILabel!
    @IBOutlet weak var carbonLbl: UILabel!
    @IBOutlet weak var colorLbl: UILabel!
    @IBOutlet weak var carTypeLbl: UILabel!
    static func getSize() -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width-20, height: 100)
    }
    
    static func reuseIdentifier() -> String {
        return "EmissionCollectionViewCell"
    }

}
